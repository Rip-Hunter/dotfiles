curl -o - https://gitlab.com/stephan-raabe/dotfiles/-/raw/main/.install/version.txt?ref_type=heads&inline=false
echo $live_version