#!/bin/bash
sleep 1
killall -9 Hyprland sleep 2