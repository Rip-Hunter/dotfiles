#!/bin/bash
cd ~/dotfiles/hypr/settings
exec ./settings.sh