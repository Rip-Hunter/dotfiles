#!/bin/bash
echo $(cat ~/dotfiles/.version/name) $(cat ~/dotfiles/.version/version)
